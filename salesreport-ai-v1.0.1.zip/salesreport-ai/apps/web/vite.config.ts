import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://localhost:4000', changeOrigin: false } },
  },
  preview: { port: 4173, proxy: { '/api': 'http://localhost:4000' } },
  build: {
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
});
